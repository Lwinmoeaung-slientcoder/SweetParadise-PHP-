
<script>
	//Buy Items
    function Back(){
        location.href ="../index.php";
    }

	function Buyitems()
	{
	     location.href ="index.php";
	}
  function Contact()
	{
	     location.href ="../general/Contact.php";
	}
  function About()
	{
	     location.href ="../general/About.php";
	}
  function Order()
	{
	     location.href ="../order";
	}

	function confrim()
	{
		if (confirm('Are you sure to Buy?')) {
			location.href ="receipt.php";

		}else{

			header('Location: index.php');
		}

	}

	//Login Page
	function LoginBack()
	{
	     location.href =".php";
	}
	function LoginEnter()
	{
	     location.href ="";
	}
  function Logout()
	{
	     location.href ="logout.php";
	}

	//Main.php
	function Order()
	{
	     location.href ="order";
	}
	function Enter()
	{
	     location.href ="sale/itemsmenu.php";
	}

  //admin

</script>

<?php

$conn=mysqli_connect("localhost","root","","bakery");
if(!$conn){
  die('Query Failed'.mysqli_error($conn));

}else{
//echo "<script>alert('Success')</script>";
}
?>


<!--class="active"-->

<body>
<!------ Include the above in your HEAD tag ---------->
<h1>ADMIN PANEL</h1>
    <hr>

        <div role="tabpanel">
            <div class="col-sm-2">
                <ul class="nav nav-pills brand-pills nav-stacked" role="tablist">
                    <li role="presentation" class="brand-nav" class="active"><a href="../../admin/admin_include/index.php" aria-controls="tab1" role="tab" data-toggle="tab">Admin_Information</a></li>
                    <li role="presentation" class="brand-nav"><a href="../../admin/admin_include/admin_view_all_items.php" aria-controls="tab2" role="tab" data-toggle="tab">View_ALL_Items</a></li>
                    <li role="presentation" class="brand-nav"><a href="../../admin/admin_include/admin_list.php" aria-controls="tab3" role="tab" data-toggle="tab">Admins list</a></li>
                    <li role="presentation" class="brand-nav"><a href="../../admin/admin_include/createadmin.php" aria-controls="tab4" role="tab" data-toggle="tab">Create Admin</a></li>
                    <li role="presentation" class="brand-nav"><a href="../../admin/admin_include/add_item.php" aria-controls="tab5" role="tab" data-toggle="tab">Add Items</a></li>
                </ul>
            </div>


        </div>

</body>
</html>

<hr>
<footer class="container-fluid text-center">

        <div class="copyrights">
            <p class="white-txt"><p>&copy;2019 Copyright by Sweet Paradise.</p>

                <img class="footimg" src="../img/fb.png" style="height: 50px;width: 60px;" alt="Logo">
            </p>
        </div>
        <div class="navbar navbar-default">
            <p class="white-txt small" style="color:blue">
        	<a href="#"><font color="red">Contact Us</font></a>&nbsp
            <a href="#"><font color="red">Privacy Policy</font></a>&nbsp
            <a href="#"><font color="red">Terms & Conditions</font></a>
            <br><br>
              Thank you for trusting us, for showing faith in us, and for letting us know that you will watch our back. Happy Thanksgiving!
            </p>
        </div>
</footer>

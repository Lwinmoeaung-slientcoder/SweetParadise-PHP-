<?php
session_start();
if ($_SESSION['login_Auth']==1) {
ob_start();
require_once '../../resource/Config/dbconfig.php';
include_once '../../resource/front/admin_header.php';
include_once '../../resource/front/admin_nav.php';
$sql="SELECT * FROM inventory";
$result=mysqli_query($conn,$sql);

?>

<div class="col-sm-10">
<table class="table" style="color:white">
  <thead class="thead-light">
                                    <tr>
                                        <th>id</th>
                                        <th>type</th>
                                        <th>name</th>
                                        <th>price</th>
                                        <th>Attribute</th>
                                        <th>total</th>
                                        <th>ingrediant</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                               <?php
                                   while ($rows = mysqli_fetch_array($result)) {
                                    ?>

                                    <tr>
                                      <td><?php echo $rows['id']; ?></td>
                                      <td><?php echo $rows['type']; ?></td>
                                       <td><?php echo $rows['name']; ?></td>
                                       <td><?php echo $rows['price']; ?></td>
                                       <td><?php echo $rows['Attribute']; ?></td>
                                       <td><?php echo $rows['total']; ?></td>
                                       <td><?php echo $rows['ingedriant']; ?></td>
                                       <form action="" method="post">
                                           <td><button type="submit" class="btn btn-primary btn-sm" name="edit" value="<?php echo $rows['id']; ?>">Edit</button></td>
                                       </form>
                                       <form action="#" method="post">
                                          <td> <button type="submit" class="btn btn-danger btn-sm" name="delete" value="<?php echo $rows['id']; ?>">Delete</button></td>
                                       </form>
                                      </td>
                                    </tr>

                                  <?php
                                  }
                                  ?>
                                    </tbody>
                                </table>
                              </div>


                                <?php
                                if (isset($_POST['delete'])) {
                                	# code...
                                $ingre_value=$_POST['delete'];
                                $sql = "DELETE FROM inventory WHERE id='$ingre_value'";
                                 $results= mysqli_query($conn, $sql);
                                 header('Location: admin_view_all_items.php');
                                }
                                ?>
                                <?php
                               }
                               else {
                                 header('Location: ../index.php');
                               }
                                 ?>

<?php
session_start();
if ($_SESSION['login_Auth']==1) {
require_once '../../resource/Config/dbconfig.php';
include_once '../../resource/front/admin_header.php';
include_once '../../resource/front/admin_nav.php';


$sql="select * FROM inventory";
  if ($result=mysqli_query($conn,$sql)) {
    $rowcount=mysqli_num_rows($result);
    echo "<html><font color='red' size='3'>You can set your id from more than $rowcount</font></html>";
  if(isset($_POST["createpost"]))
  {
          $useritem_id=$_POST['itemid'];
            if ($useritem_id<=$rowcount)
            {
                ?>
<script>
  $(document).ready(function(){
       $("#item_id").css("background-color","red");
     });
</script>
<?php
             }
              else
              {
                   $itemid=$_POST['itemid'];
                   $itemtype=$_POST['itemtype'];
                   $itemname=$_POST['itemname'];
                   $itemprice=$_POST['itemprice'];
                //     $post_category_id=$_POST['post_category_id'];
                //     $post_author=$_POST['post_author'];
                //     $post_status=$_POST['post_status'];
                //
                //     $post_image=$_FILES['postimage']['name'];
                //     $post_image_temp=$_FILES['postimage']['tmp_name'];
                //     move_uploaded_file($post_image_temp,"../image/$post_image");
                //
                //     $post_tag=$_POST['post_tag'];
                //     $post_content=$_POST['post_content'];
                //     $post_date=date('d-m-y');
                //     $post_comment_count=5;
                //
                    $query="INSERT INTO inventory(id,type,name,ingedriant,price) VALUES ('$itemid','$itemtype','$itemname','','$itemprice')";
                    $result = mysqli_query($conn,$query);
                    ?>
                    <script>
                             alert("Successfully added");
                    </script>
                    <?php
                    header('Location:add_item.php');
                   if(!$result){
                       die('Query Faile'.mysqli_error($conn));
                     }
                //echo "<html><font color='red'>$itemid$itemtype$itemname$itemprice</font></html>";
              }
  }
}
?>
<div class="col-sm-10">
  <font color="white">
<form action="#" method="post" enctype="multipart/form-data">
            <div class="form-group">
                 <label for="" class="control-label">Item ID</label>
                 <input type="text" class="form-control" id="item_id" name="itemid">
            </div>
            <div class="form-group">
                <label for="" class="control-label">Item Type</label>
                  <select name="itemtype" id="" class="form-control" required="">
                        <option selected hidden>Choose here</option>
                        <option value='cakes'>cakes</option>
                        <option value='bread'>bread</option>
                        <option value='hotdrink'>hotdrink</option>
                        <option value='colddrink'>colddrink</option>
                  </select>
            </div>

            <div class="form-group">
                <label for="" class="control-label">Item Name</label>
                <input type="text" class="form-control" name="itemname" required="">
            </div>
            <div class="form-group">
                <label for="" class="control-label">Item Image</label>
                <input type="file" name="itemimage">
            </div>
            <div class="form-group">
                <label for="" class="control-label">Item Price</label>
                <input type="text" class="form-control" name="itemprice" required="">
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" name="createpost" value="Add Post">
</font>
            </div>
</form>
<div class="col-sm-10">
  <?php
 }
 else {
   header('Location: ../index.php');
 }
   ?>

<?php
session_start();
require_once '../resource/Config/dbconfig.php';

$sql="SELECT * FROM login";
$result=mysqli_query($conn,$sql);

if (isset($_POST['Login'])) {
  # code...
  if (empty($_POST['user']) || empty($_POST['pass'])) {
  $error = "Username or Password is invalid";
  header('Location: index.php');
}
else{
   $user=$_POST['user'];
   $pwd=$_POST['pass'];

 while ($rows = mysqli_fetch_array($result)) {
 $username=$rows['username'];
 $password=$rows['password'];
        if ($user===$username&&$pwd===$password) {
          $_SESSION['login_user'] = $username;
          $_SESSION['login_pwd'] = $password;
          $_SESSION['login_Auth']=1;
              header('Location: admin_include');
          }
        }
      }
       mysqli_close($conn); // Closing Connection
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../css/bootstrap.min.css" rel="stylesheet">
     <link href="../css/Login.css" rel="stylesheet">
     <script src="../js/jquery.min.js"></script>
     <script src="../js/bootstrap.min.js"></script>

</head>
<body>

<div class="container text-center">
	<h1>Sweet Paradise</h1><br>
		<h3>Bakery & Cafe</h3>
		<hr>
		<h4>To Inventory</h4>
</div>
<!-- Start -->
    <!-- Page Content -->
    <div class="container">

<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Login</h1>
                    <form role="form" action="#" method="post" id="login-form" autocomplete="off">
                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input type="text" name="user" id="username" class="form-control" placeholder="Enter Desired Username" required="">
                        </div>
                         <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="pass" id="key" class="form-control" placeholder="Password" required="">
                        </div>

                        <input type="submit" name="Login" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Login">

                    </form>

                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>
        <hr>
</body>
</html>

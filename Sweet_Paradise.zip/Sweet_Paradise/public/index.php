<?php include_once "../resource/Config/function.php";?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../css/bootstrap.min.css" rel="stylesheet">
     <link href="../css/home.css" rel="stylesheet">
     <script src="../../js/jquery.min.js"></script>
     <script src="../js/bootstrap.min.js"></script>

	<title>Home</title>
</head>
<body>
	<div class="container text-center">

		<h1>Sweet Paradise</h1><br><br>
		<h3>❤️❤️❤️❤️❤️</h3><br><br>
		<h3>いらしゃいませ</h3>

		<button type="button" class="btn btn-lg firstbtn" onclick="Order()">Order</button>
		<button type="button" class="btn btn-lg secondbtn" onclick="Enter()">Buy Now</button>
	</div>

</body>
</html>

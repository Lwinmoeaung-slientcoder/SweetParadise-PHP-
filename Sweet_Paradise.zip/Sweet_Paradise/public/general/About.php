	<!DOCTYPE html>
	<html>
	<head>

	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../css/bootstrap.min.css" rel="stylesheet">
     <link href="../css/About.css" rel="stylesheet">
	<link rel="stylesheet" href="../css/font-awesome.min.css">
     <script src="../js/jquery.min.js"></script>
     <script src="../js/bootstrap.min.js"></script>
     
		<title>About</title>
		<style>
			body{
				background: white;
			}
		</style>
	</head>

		<center><div class="header"><h1><b>About Our Shop</b></h1></div></center>
		<div class="container container">

			<div class="row">
				<div class="col-md-3">
				<img src="../img/p1.png" class="img-circle" alt="Cinque Terre" style="height: 150px;width: 230px;"><br>

				</div>
				<div class="col-md-7 text-justify">
				<p> Café Sweets Bakery caters to customers with diverse backgrounds and lifestyles. It is our goal to make.
the process of placing an order easy and convenient for you. In order to provide you with exceptional.
 service and deliver the best freshly baked products, please review our Customer Service policy listed
 below.

Pick-Up Orders

All orders made online are available for pick up at our bakery location 505 Clematis Street, West Palm
 Beach, Florida within 1 hour of placing the order during normal store hours MTW 7:30AM-6:00PM,
 THFS 7:30AM-10:30PM. Since we bake fresh daily, any orders consisting of 3 dozen or more, are treated
 as special orders and are subject to availability for same day pick up, but are always available within a
 24 hour notice.

Advance Orders

We are delighted to fulfill any advance orders. We take advance orders up to 120 days in advance when
you need to plan for your perfect event. We do require that payment be made in full for all advance orders
 45 days prior to date of the event.


Special Orders (24-hour advance notice required)

Special orders are a dream for Pastry Chef Sharlyn Davis! Special orders can take on many different forms and this is an opportunity for Sharlyn to put her love for
 creativity and pastry design skills to work.  Any pastry order of 3 dozen or more is considered a special
 order, as we bake a small quantity of products fresh daily. We want to be sure your special order of
 choice is available and we require 24-hour advance notice. Other examples of special orders would be
 dietary restrictions, custom flavors, or custom designs.

Delivery Policy

We are currently evaluating demand for delivery. At this time, we are happy to deliver any special order
within 24 hours of when the order is placed and delivery is within a 3-5 mile radius of our bakery
 location. There is no delivery charge under these conditions.</p>
				</div>
			</div>

<?php include_once "../include/footer.php"; ?>
</div>

	</body>
	</html>

<?php
	 require_once '../../resource/Config/dbconfig.php';

 	$sql = "SELECT * FROM item_order";
    $results= mysqli_query($conn, $sql);

 ?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../../css/bootstrap.min.css" rel="stylesheet">
     <link href="../../css/receipt.css" rel="stylesheet">
     <script src="../../js/jquery.min.js"></script>
     <script src="../../js/bootstrap.min.js"></script>


</head>

<body>
	<div class="container">
		<?php include_once "header.php"?>
		<div class="row">
			<div class="col-md-6">

				<?php  echo "Date : " . date('d/M/Y'); ?>
</div>

		</div>
		<div class="row">
			<div class="col-lg-12 col-md-12">
	 <table class="table">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Type</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                               <?php
                                    while ($rows = mysqli_fetch_array($results)) {

                                    ?>
                                    <tr>
                                        <td><?php echo $rows['id']; ?></td>
                                        <td><?php echo $rows['name']; ?></td>
                                        <td><?php echo $rows['price']; ?></td>
                                        <td><?php echo $rows['type']; ?></td>
                                  <?php
                                  }
                                  ?>

                                    </tbody>

                                </table>
                 </div>
		 </div>
		 <?php include_once "footer.php"?>
</div>
</body>

<!--/*dbconnection*/-->
<?php
ob_start();
include_once "../../resource/Config/function.php";
require_once '../../resource/Config/dbconfig.php';


if (isset($_POST['submit'])) {
    # code...
    $sql_name = $_POST['submit'];

    //$sql = "SELECT * FROM inventory WHERE type='cakes'";
    $sql = "SELECT * FROM inventory WHERE name='$sql_name'";
    $results = mysqli_query($conn, $sql);
    while ($rows = mysqli_fetch_array($results)) {
      $id=$rows['id'];
      $name=$rows['name'];
      $price=$rows['price'];
      $total=$rows['total'];
      $sql1="INSERT INTO item_order (id,name,total_count,price) VALUES ('$id','$name','$total','$price')";
     $results1 = mysqli_query($conn, $sql1);

    }

     $sql2 = "SELECT * FROM item_order";
    $results2 = mysqli_query($conn, $sql2);
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../../css/bootstrap.min.css" rel="stylesheet">
     <link href="../../css/Inventory.css" rel="stylesheet">
     <script src="../../js/jquery.min.js"></script>
     <script src="../../js/bootstrap.min.js"></script>


</head>
<body>


<!------ Include the above in your HEAD tag ---------->


<div class="container">
	<?php include_once "header.php"; ?>


                <div class="container container1">
    <div class="row">
        <div class="col-md-6">
            <div class="tab" role="tabpanel">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation"><a href="#Section1" aria-controls="home" role="tab" data-toggle="tab">BREAD</a></li>
                    <li role="presentation"><a href="#Section2" aria-controls="profile" role="tab" data-toggle="tab">CAKE</a></li>
                    <li role="presentation"><a href="#Section3" aria-controls="messages" role="tab" data-toggle="tab">COLD DRINKS</a></li>
                     <li role="presentation"><a href="#Section4" aria-controls="messages" role="tab" data-toggle="tab">HOT DRINKS</a></li>
                </ul>
                <!-- Tab panes -->
                            <div class="tab-content tabs">
                                <div role="tabpanel" class="tab-pane fade in active" id="Section1">
                                    <table class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Item</th>
                  <th scope="col">Buy</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <?php include_once "Bread.php"; ?>

                </tr>
              </tbody>
            </table>
                           </div>
                                 <div role="tabpanel" class="tab-pane fade" id="Section2">
                                    <table class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Item</th>
                  <th scope="col">Buy</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <?php include_once "cake.php"; ?>
                </tr>
              </tbody>
            </table>
                           </div>
                                 <div role="tabpanel" class="tab-pane fade" id="Section3">
                                    <table class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Item</th>
                  <th scope="col">Buy</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <?php include_once "Colddrinks.php"; ?>

                </tr>
              </tbody>
            </table>
                           </div>
                                 <div role="tabpanel" class="tab-pane fade" id="Section4">
                                    <table class="table table-sm">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Item</th>
                  <th scope="col">Buy</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <?php include_once "Hotdrinks.php"; ?>

                </tr>
              </tbody>
            </table>
                           </div>
                  </div>
             </div>
        </div>

        <!--DataTable -->
                <?php
                     $sql2 = "SELECT * FROM item_order";
                     $results2 = mysqli_query($conn, $sql2);
                      include_once "Buyitems_buytable.php"
                 ?>

</div>
<?php include_once "footer.php"?>
</div>

        </body>
</html>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

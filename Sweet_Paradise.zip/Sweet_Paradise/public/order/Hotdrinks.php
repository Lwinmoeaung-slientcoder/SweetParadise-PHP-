<?php

require_once '../../resource/Config/dbconfig.php';

$query="SELECT * FROM inventory WHERE type='hotdrink'";
$result=mysqli_query($conn,$query);


while ($row=mysqli_fetch_assoc($result)) {
	# code...
	$item_id=$row['id'];
	$item_name=$row['name'];
	$item_type=$row['type'];
	$item_price=$row['price'];

?>

 <tr>
      <th scope="row"><?php echo $item_id;?></th>
      	<td >

      	<img src="../../img/p2.jpg" class="img-rounded" alt="" style="width: 200px;height: 150px;">
      	</td>

      <td>
      	<form action="index.php" method="post">
      		<input class="btn btn-success" type="submit" name="submit" value="<?php echo $item_name ?>">
          <!--    <button type="submit" class="btn btn-success" name="submit"><?php echo $item_name ?></button>-->
        </form>
     </td>
 </tr>

    <?php
}

    ?>

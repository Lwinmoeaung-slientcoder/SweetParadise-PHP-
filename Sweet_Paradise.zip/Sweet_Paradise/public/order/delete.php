<?php
ob_start();
include_once "../../resource/Config/function.php";
require_once '../../resource/Config/dbconfig.php';
//Plus
if (isset($_POST['plus'])) {
	// code...
	$sqlname=$_POST['plus'];
	$inv_sql = "SELECT price FROM inventory WHERE name='$sqlname'";
	$inv_result = mysqli_query($conn, $inv_sql);
	while ($row=mysqli_fetch_assoc($inv_result)) {
		$inv_price=$row['price'];
	}

	$sql = "SELECT price,total_count FROM item_order WHERE name='$sqlname'";
	$result = mysqli_query($conn, $sql);
	while ($row=mysqli_fetch_assoc($result)) {
		$totalcount=(int)$row['total_count'];
		$sale_price=$row['price'];
     $totalcount=$totalcount+1;
		 $sale_price=$sale_price+$inv_price;
		 $sql1="UPDATE item_order SET price=$sale_price,total_count=$totalcount WHERE name='$sqlname'";
		 $result1=mysqli_query($conn,$sql1);
			$sql2 = "SELECT * FROM item_order";
				$results2 = mysqli_query($conn, $sql2);
		 include_once "index.php";
 }

}
//Minus
if (isset($_POST['minus'])) {
	// code...
	$sqlname=$_POST['minus'];
	$inv_sql = "SELECT price FROM inventory WHERE name='$sqlname'";
	$inv_result = mysqli_query($conn, $inv_sql);
	while ($row=mysqli_fetch_assoc($inv_result)) {
		$inv_price=$row['price'];
	}

	$sql = "SELECT price,total_count FROM item_order WHERE name='$sqlname'";
	$result = mysqli_query($conn, $sql);
	while ($row=mysqli_fetch_assoc($result)) {
		$totalcount=(int)$row['total_count'];
		$sale_price=$row['price'];
		if ($totalcount>1) {
     $totalcount=$totalcount-1;
		 $sale_price=$sale_price-$inv_price;
		 $sql1="UPDATE item_order SET price=$sale_price,total_count=$totalcount WHERE name='$sqlname'";
		 $result1=mysqli_query($conn,$sql1);
			$sql2 = "SELECT * FROM item_order";
				$results2 = mysqli_query($conn, $sql2);
		 include_once "index.php";
	 }else {
		 $sql2 = "SELECT * FROM item_order";
			 $results2 = mysqli_query($conn, $sql2);
		include_once "index.php";
	 }

 }

}



//delete
	if (isset($_POST['delete'])) {
		$sqlname=$_POST['delete'];
		$sql="DELETE FROM item_order WHERE name='$sqlname'";
		$result=mysqli_query($conn,$sql);
		 $sql2 = "SELECT * FROM item_order";
			 $results2 = mysqli_query($conn, $sql2);
		include_once "index.php";
	}

?>

<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../css/bootstrap.min.css" rel="stylesheet">
     <link href="../css/Inventory.css" rel="stylesheet">
     <script src="../js/jquery.min.js"></script>
     <script src="../js/bootstrap.min.js"></script>


</head>

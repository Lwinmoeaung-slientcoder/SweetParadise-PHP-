<?php
include_once "../../resource/Config/function.php";
 $sum=0;

?>
<div class="col-md-6">
                                <table class="fixed_header tableplace" id="myTable">
                                    <thead>
                                    <tr>

                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th>Action</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                               <?php
                                    while ($rows = mysqli_fetch_array($results2)) {
                                    ?>

                                    <tr>

                                        <td><?php echo $rows['name']; ?></td>
                                        <td><?php echo $rows['price']; ?></td>
                                        <td><?php echo $rows['total_count']; ?></td>

                                        <td>


            <form action="delete.php" method="post">
              <div class="btn-group" role="group">
                <button type="submit" class="btn btn-success btn-sm" name="plus" value="<?php echo $rows['name'];?>"><span class="glyphicon glyphicon-plus"></span></button>
                <button type="submit" class="btn btn-danger btn-sm" name="delete" value="<?php echo $rows['name']; ?>"><span class="glyphicon glyphicon-remove"></span></button>
                <button type="submit" class="btn btn-primary btn-sm" name="minus" value="<?php echo $rows['name'];?>"><span class="glyphicon glyphicon-minus"></span></button>
              </div>
            </form>
                                      </td>
                                    </tr>

                                  <?php
                            $sum += $rows['price'];
                                  }
                                  ?>
                                    </tbody>

                                </table>


                                <button type="button" class="btn btn-success clearbtn" onclick="Back()">BackTo Menu</button>
                                <button type="button" class="btn btn-success confirmbtn" onclick="confrim()">Confirm</button>


                            </div>

                            </div>

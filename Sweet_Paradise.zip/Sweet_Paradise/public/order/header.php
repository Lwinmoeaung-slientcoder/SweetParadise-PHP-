	<div class="row">

    		<div class="col-md-5">
    			<div class="hd">Sweet Paradise</div>
   				<div class="hd1">Bakery & Cafe</div>

   			 </div>

    		<div class="col-md-7">

    			<div class="hd2">Deserts Make Everything Better</div>

   			</div>
	</div>	

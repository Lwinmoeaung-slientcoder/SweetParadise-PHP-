<?php include_once "../../resource/Config/function.php";?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="../../css/bootstrap.min.css" rel="stylesheet">
     <link href="../../css/itemsmenu.css" rel="stylesheet">
     <script src="../../js/jquery.min.js"></script>
     <script src="../../js/bootstrap.min.js"></script>
</head>
<body>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
	<div class="row">
		<h1>Main Menu</h1>
		<hr>
        <div role="tabpanel">
            <div class="col-md-4 col-sm-12">
                <ul class="nav nav-pills brand-pills nav-stacked" role="tablist">
                    <li role="presentation" class="brand-nav"><button type="button" class="btn btn-lg">Home</button></li><br><br>
                    <li role="presentation" class="brand-nav"><button type="button" class="btn btn-lg" onclick="Contact()">Contact</button></li><br><br>
                    <li role="presentation" class="brand-nav"><button type="button" class="btn btn-lg" onclick="About()">About</button></li><br><br>
                    <li role="presentation" class="brand-nav"><button type="button" class="btn btn-lg" onclick="Order()">Order</button></li>
                </ul>
            </div>
            <div class="col-md-4 col-sm-6 place">

                      <button type="button" class="btn btn-default btn-lg" onclick="Buyitems()">Bread</button><br><br><br><br>
                      <button type="button" class="btn btn-default btn-lg" onclick="Buyitems()">Cold Drinks</button><br><br>

            </div>

             <div class="col-md-4 col-sm-6 place">

                      <button type="button" class="btn btn-default btn-lg" onclick="Buyitems()">Cake</button><br><br><br><br>
                      <button type="button" class="btn btn-default btn-lg" onclick="Buyitems()">Hot Drinks</button><br><br>

            </div>

        </div>
  </div>

            <br><br><br><br><br><br><br><br>


         <div class="row">
            <div class="col-md-12">
                <?php include_once "footer.php"; ?>

        </div>

      </div>
</div>
</body>
</html>
